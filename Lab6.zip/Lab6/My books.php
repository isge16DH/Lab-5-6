<!DOCTYPE html>
<html>
<head>
	<title>Assignment 2</title>
	<meta name="assignment 2" content="assignment page"/>
	<meta charset="utf-8" />
	<link href="main.css" rel="stylesheet" type="text/css" />
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel="stylesheet" type='text/css'>
</head>
		<? include "config.php"; ?>
		<link href="main.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
<body>
<header>
	<?php include "Header.php"; ?>
</header>

<main class="main">
		<div class="container">
			
			<div class="lista">
				<h3>Booklist</h3>
				<form>
					<input type="text" placeholder="Title" name="title">
					<input type="text" placeholder="Author" name="author">
					<button type="submit">Submit</button>
				</form>
			</div>
		</div>
		
			<?php
				@ $db = new mysqli('localhost', 'root', '', 'library');

				$searchtitle = "";
				$searchauthor = "";

				if (isset($_GET) && !empty($_GET)) {
				if (isset($_GET['title'])) {
					$searchtitle = htmlentities(trim($_GET['title']));
				}
				if (isset($_GET['author'])) {
					$searchauthor = htmlentities(trim($_GET['author']));
				}
				$query = " select * from books where onloan is true";
				$query = "SELECT
					books.bookid as bookid,
					books.title as title,
					books.onloan as onloan,
					authors.firstName as firstName,
					authors.lastName as lastName					
					FROM authors
							LEFT JOIN book_authors ON book_authors.author_id = authors.id
							LEFT JOIN books ON book_authors.book_id = books.bookid where books.onloan = 1";
				if ($searchtitle && !$searchauthor) { // Title search only
					$query = $query . " and books.title like '%" . $searchtitle . "%'";
				}
				if (!$searchtitle && $searchauthor) { // Author search only
					$query = $query . " and concat(authors.firstName, ' ', authors.lastName) like '%" . $searchauthor . "%'";
				}
				if ($searchtitle && $searchauthor) { // Title and Author search
					$query = $query . " and books.title like '%" . $searchtitle . "%' and concat(authors.firstName, ' ', authors.lastName) like '%" . $searchauthor . "%'"; // unfinished
				}
				$stmt = $db->prepare($query);
				$stmt->bind_result($bookid, $title, $onloan, $firstName, $lastName);
				$stmt->execute();

				echo '<table><thead><th>ID</th><th>Title</th><th>Author</th><th>Reserve</th></thead><tbody>';
				while ($stmt->fetch()) {
					echo "<tr>";
					echo "<td>$bookid</td><td>$title</td><td>$firstName $lastName</td>";
					echo '<td><a href="returnBook.php?bookid=' . urlencode($bookid) . '">Return</a></td>';
					echo "</tr>";
				}
				echo "</tbody></table>";


				} else {
				$query = " select * from books where onloan is true";
				$stmt = $db->prepare($query);
				$stmt->bind_result($bookid, $title, $author, $firstName, $lastName);
				$stmt->execute();

				echo '<table><thead><th>ID</th><th>Title</th><th>Author</th><th>Reserve</th></thead><tbody>';
				while ($stmt->fetch()) {
					echo '<tr>';
					echo "<td>$bookid</td><td>$title</td><td>$author</td>";
					echo '<td><a href="returnBook.php?bookid=' . urlencode($bookid) . '">Return</a></td>';
					echo '</tr>';
				}
				echo '</tbody></table>';
				}


            ?>

</main>
	 
	<?php include "footer.php"; ?>
</body>
</html>
