
    <?php

        include("config.php");

        include("header.php");

        $bookid = trim($_GET['bookid']);
        echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>';

        $bookid = trim($_GET['bookid']);      // From the hidden field
        $bookid = addslashes($bookid);

        @ $db = new mysqli('localhost', 'root', '', 'library');

            if ($db->connect_error) {
                echo "Error! Could not connect: " . $db->connect_error;
                printf("<br><a href=index.php>Return to Home Page </a>");
                exit();
            }
            
           echo "<br>Book with the ID $bookid returned!  <br>";

            // Prepare an update statement and execute it
            $stmt = $db->prepare("UPDATE books SET onloan=0 WHERE bookid = ?");// update db book, return selected book
            $stmt->bind_param('i', $bookid);
            $stmt->execute();
            printf("<br>Succesfully returned!");
            printf("<br><br><a href=Browsebooks.php>Browse more books</a>");
            printf("<br><a href=Mybooks.php>Return to My Books </a>");
            printf("<br><a href=index.php>Return to Home Page </a>");
            exit;

    ?>

    


