<?php 
$current_page = end(explode('/', $_SERVER['REQUEST_URI']));
$dbserver = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'library';

?>