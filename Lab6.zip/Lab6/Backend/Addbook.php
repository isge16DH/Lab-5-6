<!DOCTYPE html>
    <html>

        <head>
            <title>BOOKMANIA</title>
            <link rel="stylesheet" type="text/css" href="../main.css">
            <link rel="icon" type="image/png" href="img/r_icon.png"/>
            <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Oswald:300,400,500,600" rel="stylesheet">
        </head>
        <header>
          <?php include("headerBE.php"); ?>  
        </header>
        

    <br>
    <form action="Addbook.php" method="POST">
            
            You must enter both a title and an author! <br>
            <br>
                <tr>
                    <td><INPUT type="text"   name="newbooktitle" placeholder="Title"></td>
                </tr>
                <br>
                <tr>
                    <td><INPUT type="text"  name="newbookauthor" placeholder="Author"></td>
                </tr>
                <tr>
                <br>
                    <td><INPUT  type="submit" name="submit" value="ADD BOOK"></td>
                </tr>

            <br>
            <br>
    </form>
    <?php include("../footer.php"); ?>
    </html>
<?php
include("session.php");

$title = "Add new book";

?>

<?php
if (isset($_POST['newbooktitle'])) {
    // This is the postback so add the book to the database
    # Getting entered data from form
    $newbooktitle = trim($_POST['newbooktitle']);
    $newbookauthor = trim($_POST['newbookauthor']);


    #Checking that data for both title and author is entered, if not print error
    if (!$newbooktitle || !$newbookauthor) {
        printf("You must specify both a title and an author");
        printf("<br><a href=indexBE.php>Return to home page </a>");
        exit();
    }

    #If information is entered add slashes so code is processed easily if signs are entered in text
    $newbooktitle = addslashes($newbooktitle);
    $newbookauthor = addslashes($newbookauthor);

    # htmlentities converts all applicable characters to HTML entities. ex: <b>bold</b> outputs: &lt;b&gt;bold&lt;/b&gt;
    $newbooktitle = htmlentities($newbooktitle);
    $newbookauthor = htmlentities($newbookauthor);

    # Open the database using the "librarian" account creating connection
    @ $db = new mysqli('localhost', 'root', '', 'library');
    
    #Explaining error if problems connecting to DB
    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=indexBE.php>Return to home page </a>");
        exit();
    }

    // Prepare an insert statement and execute it 
    $stmt = $db->prepare("insert into books values (null, ?, ?, false)");

    #Binding variables to a prepared statement as parameters - 'ss' stands for the values being two strings. 
    $stmt->bind_param('ss',$newbookauthor, $newbooktitle);
    
    #execute statement
    $stmt->execute();

    printf("<br>Book Added!");
    printf("<br><a href=indexBE.php>Return to home page </a>");
    exit;
}

?>
