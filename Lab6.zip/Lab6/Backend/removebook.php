<?php include("session.php"); ?>
<html>
<head>
	<title>BOOKMANIA</title>
	<link rel="stylesheet" type="text/css" href="../main.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>

<body>
	<div id="pagecontainer">
		<header>

			<?php
			include '../config.php';
			$title = "Search books";
			include 'headerBE.php'; 
			?>
		</header> 

		<div id="browsform">
			<p class="titlepage">Browse books.</p>
			<p class="titledescript">Search for books in our library.</p>
			
			<form action="removebook.php" method="POST">
				<table cellpadding="6">
					<tbody>
						<tr>
							<td>Title:</td>
							<td><input type="text" name="searchbytitle"></td>
						</tr>
						
						<tr>
							<td>Author:</td>
							<td><input type="text" name="searchbyauthor"></td>
						</tr>

						<tr>
							<td></td>
							<td><input type="submit" name="submit" value="Submit It"></td>
						</tr>
					</tbody>
				</table>
			</form>


			<p class="titlepage">Booklist</p>
			


			<?php 
$searchbytitle = "";
$searchbyauthor = "";

#Checking if postform is set and not empty ->
if (isset($_POST) && !empty($_POST)) {

    #triming all inputs from whitespace or not allowed characters 
    $searchbytitle = trim($_POST['searchbytitle']);
    $searchbyauthor = trim($_POST['searchbyauthor']);
}


#addlsashes returns a string with backslashes before characters that need to be escaped also makes code
$searchbytitle = addslashes($searchbytitle);
$searchbyauthor = addslashes($searchbyauthor);

#connecting to database, variables found in config file 
@ $db = new mysqli('localhost', 'root', '', 'library');

if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=indexBE.php>Return to home page </a>");
    exit();
}

#Building query against DB - select values all from table books
$query = " select * from books";  

if ($searchbytitle && !$searchbyauthor) { // Title only
    $query = $query . " where title like '%" . $searchbytitle . "%'"; //any title containing what is entered 
}
if (!$searchbytitle && $searchbyauthor) { // Author search only
    $query = $query . " where author like '%" . $searchbyauthor . "%'"; //any author containing what is entered
}
if ($searchbytitle && $searchbyauthor) { // Title and Author search
    $query = $query . " where title like '%" . $searchbytitle . "%' and author like '%" . $searchbyauthor . "%'"; 
}


 

//Printing information 
    #Prepare query for execution (which query depends on entered information, explained above.)
    $stmt = $db->prepare($query); 

    #Binds variables to a prepared statement for result storage, whatever is taken out needs to be assigned (to the right place)
    $stmt->bind_result($bookid, $author, $title, $firstName, $lastName); 
	
    $stmt->execute();  

    echo '<table cellpadding="10">';
    echo '<tr><td>ID</td> <b><td>Title</td> <td>Author</td> <td>Reserved?</td> <td>Remove</td> </b> </tr>';
    while ($stmt->fetch()) {
    	if($onloan == 0) // if the book is not on loan
    		$onloan='NO'; // say no 
    	else $onloan='YES'; // else say yes

        echo "<tr>";
        echo "<td> $bookid </td><td> $title </td><td> $author </td><td> $onloan </td>";

        #echo out Remove-button link - while pressed goes to deletebook.php and adds bookid to the URL - later used to remove in deletebook.php
        echo '<td><a href="deletebook.php?bookid=' . urlencode($bookid) . '"> Remove </a></td>';
        echo "</tr>";
    }
    echo "</table>";
    ?>



</div>



</body>
</html>