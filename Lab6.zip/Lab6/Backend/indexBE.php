<?php include("session.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>BOOKMANIA</title>
	<link rel="stylesheet" type="text/css" href="../main.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>
	<?php include '../config.php'; ?>
<body>
	<div id="pagecontainer">
		<header>
			<?php include 'headerBE.php'; ?>
		</header> 
	</div>

</body>
</html>