<?php
session_start();
if (!isset($_SESSION['adminname'])) {
    header("../main_login.php");
} ?>


