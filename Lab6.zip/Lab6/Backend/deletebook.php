<!DOCTYPE html>
    <html>

        <head>
            <title>BOOKMANIA</title>
            <link rel="stylesheet" type="text/css" href="../main.css">
            <link rel="icon" type="image/png" href="img/r_icon.png"/>
            <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Oswald:300,400,500,600" rel="stylesheet">
        </head>
        <header>
          <?php include("headerBE.php"); ?>  
        </header>

<?php
include("session.php");
include("../config.php");
$title = "Delete book";
?>

<?php
if (isset($_GET['submit'])) {
    #getting bookid from url
    $bookid = trim($_GET['bookid']);      
    $bookid = addslashes($bookid);

    # Open the database using the "librarian" account
    @ $db = new mysqli('localhost', 'root', '', 'library');

    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=index.php>Return to home page </a>");
        exit();
    }

    // Prepare an update statement based on chosen bookid from list and execute it(deleting book from DB) 
        $stmt = $db->prepare("delete from books where bookid = ?");
        $stmt->bind_param('i', $bookid);
        $response = $stmt->execute();
        printf("<br>Book deleted!");
        printf("<br><a href=Addbook.php>Return to home page </a>");
    
    
    exit;
}


?>



<br>
<form action="deletebook.php" method="GET">
    Are you sure you want to delete this book?
    <br>
    <?php
    $bookid = trim($_GET['bookid']);
    echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>';
    ?>
    <INPUT id="upload_button" type="submit" name="submit" value="DELETE BOOK">
</form>
<?php include("../footer.php"); ?>

</html>