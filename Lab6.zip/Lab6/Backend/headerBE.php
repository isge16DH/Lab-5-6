
		<nav id="basicMenu">
			<ul >
				<li class="panomenu"><a class="<?php echo ($current_page == 'addbook.php') ? 'active' : NULL ?>" href="addbook.php">add books</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'logout.php') ? 'active' : NULL ?>" href="removebook.php">remove books</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'addbook.php') ? 'active' : NULL ?>" href="fileUpload.php">upload pictures to gallery</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'logout.php') ? 'active' : NULL ?>" href="logout.php">log out</a></li>
			</ul>
		</nav>
