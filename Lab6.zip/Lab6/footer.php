<?php
$cookie_name = "user";
$cookie_value = "John Doe";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
?>
<body>

<?php
if(!isset($_COOKIE[$cookie_name])) {
    echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
    echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $_COOKIE[$cookie_name];
}
?>

</body>
<footer href="http://localhost/php%20Lab6/Home.php" href="http://localhost/php%20Lab6/About%20us.php" href="http://localhost/php%20Lab6/Browse%20Books.php" href="http://localhost/php%20Lab6/My%20books.php" href="http://localhost/php%20Lab6/Contact.php">  Copyright 2015, All rights reserved, Bookmania </footer> 
