<!DOCTYPE html>
<html>
    <head>
        <title>BOOKMANIA:</title>
        <link rel="stylesheet" type="text/css" href="main.css">
        <link rel="icon" type="image/png" href="img/r_icon.png"/>
        <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900|Oswald:300,400,500,600" rel="stylesheet">
    </head>
    	<?php include 'config.php'; ?>
    
<header>
  <?php include("header.php"); ?>
</header>
    <body>


    <div id="upload_container">	

            <?php
                $folder_path = 'img/'; //image's folder pathe


                $num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);

                $folder = opendir($folder_path);

                if($num_files > 0)
                {
                 while(false !== ($file = readdir($folder)))
                 {
                  $file_path = $folder_path.$file;
                  $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
                  if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp')
                  {
            ?>
                        
             <a href="<?php echo $file_path; ?>"><img src="<?php echo $file_path; ?>"  height="250" /></a>
     <?php
          }
         }
        }
        else
        {
         echo "empty folder";
        }
        closedir($folder);
        ?>

	</div>

	<?php
		include ("footer.php")
	?>

	</body>

</html>