<!DOCTYPE html>
<html>
<head>
	<title>Assignment 2</title>
	<meta name="assignment 2" content=”assignment page"/>
	<meta charset="utf-8" />
	<link href="main.css" rel="stylesheet" type="text/css" />
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel="stylesheet" type='text/css'>
</head>
    <? include "config.php"; ?>
    <link href="main.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
<body>
<header>
	<?php include "Header.php"; ?>
</header>
	

<main class="main">
	<div class="containerF">
		<form id="contact" action="<?= $_SERVER ['PHP_SELF']; ?>" method="post">
          <h3>Get In Touch</h3>
          

          <label for="fullname">Full Name</label>
          <input type="text" id="fullname" name="firstname" placeholder="James Robers..">

          <label for="Email">Mail Address</label>
          <input type="text" id="Email" name="Email" placeholder="Joh@mail.com">

          <label for="Phone">Country</label>
          <input type="text" id="PhoneNumber" name="Phone Number" placeholder="07********">

          <label for="subject">Subject</label>
          <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

          <input type="submit" value="Submit">

        </form>
	</div>
</main>
	 
	<?php include "footer.php"; ?>
	
</body>
</html>
