
		<h1 > bookmania </h1>
		<nav id="basicMenu">
			<ul>
				<li class="panomenu"><a class="<?php echo ($current_page == 'indexlab1.php' || $current_page == '') ? 'active' : NULL ?>" href="Home.php">Home</a></li>
				<li class="panomenu"><a class="<?php echo ($current_page == 'About%20us.php') ? 'active' : NULL ?>" href="About%20us.php">About Us</a></li>	
				<li class="panomenu"><a class="<?php echo ($current_page == 'Browse%20Books.php') ? 'active' : NULL ?>" href="Browse%20Books.php">Browse Books</a></li>
				<li class="panomenu"><a class="<?php echo ($current_page == 'My%20books.php') ? 'active' : NULL ?>" href="My%20books.php">My Books</a></li>
				<li class="panomenu"><a class="<?php echo ($current_page == 'gallery.php') ? 'active' : NULL ?>" href="gallery.php">GALLERY</a></li>
				<li class="panomenu"><a class="<?php echo ($current_page == 'Contact.php') ? 'active' : NULL ?>" href="Contact.php">Contact</a></li>
				<li class="panomenu"><a class="<?php echo ($current_page == 'main_login.php') ? 'active' : NULL ?>" href="main_login.php">Log In</a></li>
			</ul>
		</nav>
		