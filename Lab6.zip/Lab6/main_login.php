<?php

if (isset($_POST['username'], $_POST['password'])) {

   @ $db = new mysqli('localhost', 'root', '', 'library');

      if ($db->connect_error) {
         echo "could not connect: " . $db->connect_error;
         printf("<br><a href=index.php>Return to home page </a>");
         exit();
      }
    
    $aname = htmlentities($_POST['username']);
    $aname = mysqli_real_escape_string($db, $_POST['username']);
    
    $apass = MD5($_POST['password']);
    
    
    $query = ("SELECT * FROM user WHERE username = '{$aname}' "." AND password = '{$apass}'");
       
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stmt->store_result(); 
    
    
    
    $totalcount = $stmt->num_rows();  

    
        if($totalcount == 1){
            session_start();
                $_SESSION['adminname'] = $aname;
                    header('location:Backend/indexBE.php');
                    exit();
            } else{
                echo "<p>Wrong password, try again</p>";
                }

        }

?>

<!DOCTYPE html>

<html>
   
   <head>
      <title>BOOKMANIA: LOGIN</title>
        <link rel="stylesheet" type="text/css" href="main.css">
        <link rel="icon" type="image/png" href="img/r_icon.png"/>
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Oswald:300,400,500,600" rel="stylesheet">
   </head>
   
   <body>
    <header>
	    <?php include "Header.php"; ?>
    </header>
      <div id="login_container">

         <h1 id="welcome">BOOKMANIA ADMIN:</h1>
         
               
               <form id="login_form" action = "" method = "post">

                  <br><input  class="box" type = "text" name = "username" placeholder="Login">

                  <br><input  class="box" type = "password" name = "password" placeholder="Password"><br/><br />

                  <input  type = "submit" value = " LOG IN "/>

               	<p >OR</p>

                  <a id="submit" href="Home.php"> CONTINUE TO BOOKMANIA: </a><br />

               </form>

                                   
            </div>
                
         </div>
            
      </div>
      <?php include "footer.php"; ?>
   </body>

</html>