<!DOCTYPE html>
<html>
<head>
	<title>Assignment 2</title>
	<meta name="assignment 2" content="assignment page"/>
	<meta charset="utf-8" />
	<link href="main.css" rel="stylesheet" type="text/css" />
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel="stylesheet" type='text/css'>
</head>
		<?php include "config.php"; ?>
		<link href="main.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
<body>
<header>
	<?php include "Header.php"; ?>
</header>

<main class="main">
		<div class="container">
			<div>
				<h2>About us</h2>
				<p>
					Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. consectetur adipisicing elitm sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
					Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. consectetur adipisicing elitm sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
				</p>
			</div>
			<h2> Get on board </h2>
	</div>
</main>
	 
	<?php include "footer.php"; ?>
	
</body>
</html>
