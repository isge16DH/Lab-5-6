<!DOCTYPE html>
<html>
<head>
	<title>Assignment 2</title>
	<meta name="assignment 2" content="assignment page"/>
	<meta charset="utf-8" />
	<link href="main.css" rel="stylesheet" type="text/css" />
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel="stylesheet" type='text/css'>
</head>
		<link href="main.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
<body>
<header>
	<?php include "Header.php"; ?>
	<?php include "config.php" ?>
</header>
<main class="main">
		<div class="container">
				
					<h3 class="nomarg">Search</h3>
					<p class="titlepage">BROWSE BOOKS</p>
			
			<form action="Browse books.php" method="GET">
				<table cellpadding="6">					
							
					<form>
						Title:
							<input type="text" placeholder="Title" name="title">
						Author:
							<input type="text" placeholder="Author" name="author">
							<button type="submit">Submit</button>
					</form>

				</table>
			</form>


			<p class="titlepage">Booklist</p>
			
			
			<?php 
				@ $db = new mysqli('localhost', 'root', '', 'library');

				$searchtitle = "";
				$searchauthor = "";

				if (isset($_GET) && !empty($_GET)) {
				if (isset($_GET['title'])) {
					$searchtitle = $db->real_escape_string(htmlentities(trim($_GET['title'])));
				}
				if (isset($_GET['author'])) {
					$searchauthor = $db->real_escape_string(htmlentities(trim($_GET['author'])));
				}
				// $query = " select * from books";
				$query = "SELECT books.bookid as bookid, books.title as title, books.onloan as onloan, authors.firstName as firstName, authors.lastName as lastName FROM authors
							LEFT JOIN book_authors ON book_authors.author_id = authors.id
							LEFT JOIN books ON book_authors.book_id = books.bookid";
				if ($searchtitle && !$searchauthor) { // Title search only
					$query = $query . " where title like '%" . $searchtitle . "%'";
				}
				if (!$searchtitle && $searchauthor) { // Author search only
					$query = $query . " where concat(authors.firstName, ' ', authors.lastName) like '%" . $searchauthor . "%'";
				}
				if ($searchtitle && $searchauthor) { // Title and Author search
					$query = $query . " where title like '%" . $searchtitle . "%' and concat(authors.firstName, ' ', authors.lastName) like '%" . $searchauthor . "%'"; // unfinished
				}
				$stmt = $db->prepare($query);
				$stmt->bind_result($bookid, $title, $onloan, $firstName, $lastName);
				$stmt->execute();

				echo '<table><thead><th>ID</th><th>Title</th><th>Author</th><th>On Loan</th><th>Reserve</th></thead><tbody>';
				while ($stmt->fetch()) {
					echo "<tr>";
					echo "<td>$bookid</td><td>$title</td><td>$firstName $lastName</td><td>$onloan</td>";
					echo '<td><a href="reserveBook.php?bookid=' . urlencode($bookid) . '"> Reserve </a></td>';
					echo "</tr>";
				}
				echo "</tbody></table>";


				} else {
				$query = "SELECT
					books.bookid as bookid,
					books.title as title,
					books.onloan as onloan,
					authors.firstName as firstName,
					authors.lastName as lastName					
					FROM authors
							LEFT JOIN book_authors ON book_authors.author_id = authors.id
							LEFT JOIN books ON book_authors.book_id = books.bookid";
				$stmt = $db ->prepare($query);
				$stmt->bind_result($bookid, $title, $onloan, $firstName, $lastName);
				$stmt->execute();

				echo '<table><thead><th>ID</th><th>Title</th><th>Author</th><th>On Loan</th><th>Reserve</th>';
				if (isset($_SESSION['logged_in'])) {
					echo '<th>Delete</th>';
				}
				echo '</thead><tbody>';
				while ($stmt->fetch()) {
					echo '<tr>';
					echo "<td>$bookid</td><td>$title</td><td>$firstName $lastName</td><td>$onloan</td>";
					echo '<td><a href="reserveBook.php?bookid=' . urlencode($bookid) . '"> Reserve </a></td>';
					echo '</tr>';
				}
				echo '</tbody></table>';
				}
            ?>
	
</body>
</html>
